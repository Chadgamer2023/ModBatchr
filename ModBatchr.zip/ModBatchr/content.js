(() => {
  const entries = document.querySelectorAll("ul.ipsDataList > li.ipsDataItem");

  const items = Array.from(entries).map(entry => {
    const name = entry.querySelector(".ipsDataItem_title span")?.textContent.trim();
    const url = entry.querySelector("a.ipsButton_primary")?.href;
    return name && url ? { name, url } : null;
  }).filter(Boolean);

  chrome.storage.local.set({ modItems: items });
})();
