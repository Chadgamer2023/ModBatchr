(function() {
    const buttons = Array.from(document.querySelectorAll("a, button"))
      .filter(el => el.textContent.trim() === "Download this file");
  
    if (buttons.length === 0) {
      alert("No download buttons found on this page.");
      return;
    }
  
    buttons.forEach((btn, i) => {
      setTimeout(() => {
        btn.scrollIntoView({ behavior: "smooth", block: "center" });
        btn.click();
      }, i * 1000); // stagger clicks 1s apart
    });
  
    alert(`Started downloading ${buttons.length} file(s).`);
  })();
  