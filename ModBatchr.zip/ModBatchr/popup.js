document.addEventListener("DOMContentLoaded", async () => {
    const fileListEl     = document.getElementById("fileList");
    const selectAllBtn   = document.getElementById("selectAll");
    const unselectAllBtn = document.getElementById("unselectAll");
    const downloadSelBtn = document.getElementById("downloadSel");
    const downloadAllBtn = document.getElementById("downloadAll");
    const progressEl     = document.getElementById("progress");
    const folderInput    = document.getElementById("folderInput");
    const saveFolderBtn  = document.getElementById("saveFolder");
    const refreshToggle  = document.getElementById("refreshToggle");
    const downloadTabsBtn = document.getElementById("downloadTabs");
  
    let modItems       = [];
    let selected       = new Set();
    let downloadFolder = "";
    let autoRefresh    = false;
    let currentTabUrl  = "";
  
    // --- Utilities ---
  
    function sanitizeFilename(name) {
      return name.replace(/[<>:"/\\|?*]+/g, "_");
    }
  
    function getCleanZipName() {
      const m = currentTabUrl.match(/\/file\/(\d+-[a-z0-9-]+)/i);
      return m ? `${sanitizeFilename(m[1])}.zip` : `mods_bundle.zip`;
    }
  
    // --- Core ZIP+Download Logic ---
  
    function zipAndDownload(itemsToZip) {
      const zip = new JSZip();
      let count = 0;
      let failed = 0;
      progressEl.textContent = "Preparing ZIP…";
  
      Promise.all(
        itemsToZip.map(async item => {
          try {
            progressEl.textContent = `Fetching: ${item.name} (${count + 1}/${itemsToZip.length})`;
            const res = await fetch(item.url);
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const blob = await res.blob();
            let filename = sanitizeFilename(item.name);
            zip.file(filename, blob);
            count++;
            progressEl.textContent = `Added ${count}/${itemsToZip.length}`;
          } catch (err) {
            failed++;
            console.error("Fetch error:", err);
            progressEl.textContent = `Error fetching "${item.name}" (${failed} failed)`;
          }
        })
      ).then(async () => {
        if (count === 0) {
          progressEl.textContent = "All downloads failed.";
          return;
        }
        progressEl.textContent = `Zipping ${count} file(s)...`;
        const blob = await zip.generateAsync({ type: "blob" });
        const url = URL.createObjectURL(blob);
        const zipName = getCleanZipName();
        const finalName = downloadFolder
          ? `${downloadFolder}/${zipName}`
          : zipName;
  
        chrome.downloads.download({
          url,
          filename: finalName,
          saveAs: false
        }, () => {
          progressEl.textContent = failed
            ? `Download complete. (${failed} file(s) failed)`
            : "Download complete.";
        });
      });
    }
  
    // --- Initialization & UI Setup ---
  
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url) {
      currentTabUrl = tab.url;
  
      const cfg = await chrome.storage.local.get("autoRefresh");
      autoRefresh = cfg.autoRefresh || false;
      refreshToggle.checked = autoRefresh;
  
      const url = new URL(tab.url);
      if (autoRefresh &&
          url.pathname.startsWith("/files/file/") &&
          !url.searchParams.has("do")) {
        url.searchParams.set("do", "download");
        chrome.tabs.update(tab.id, { url: url.toString() });
        window.close();
        return;
      }
    }
  
    const data = await chrome.storage.local.get([
      "modItems", "selected", "downloadFolder", "autoRefresh"
    ]);
    modItems       = data.modItems || [];
    selected       = new Set(data.selected || []);
    downloadFolder = data.downloadFolder || "";
    autoRefresh    = data.autoRefresh || false;
  
    folderInput.value     = downloadFolder;
    refreshToggle.checked = autoRefresh;
  
    fileListEl.innerHTML = "";
    modItems.forEach((item, i) => {
      const div = document.createElement("div");
      div.className = "fileItem";
  
      const cb = document.createElement("input");
      cb.type        = "checkbox";
      cb.id          = `cb${i}`;
      cb.checked     = selected.has(item.url);
      cb.dataset.url = item.url;
  
      cb.addEventListener("change", () => {
        cb.checked ? selected.add(item.url) : selected.delete(item.url);
        chrome.storage.local.set({ selected: Array.from(selected) });
      });
  
      const label = document.createElement("label");
      label.htmlFor     = cb.id;
      label.textContent = item.name;
  
      div.append(cb, label);
      fileListEl.appendChild(div);
    });
  
    progressEl.textContent = `${modItems.length} file(s) listed`;
  
    // --- Event Handlers ---
  
    saveFolderBtn.onclick = () => {
      downloadFolder = folderInput.value.trim();
      chrome.storage.local.set({ downloadFolder }, () => {
        progressEl.textContent = "Folder saved.";
      });
    };
  
    refreshToggle.onchange = () => {
      autoRefresh = refreshToggle.checked;
      chrome.storage.local.set({ autoRefresh }, () => {
        progressEl.textContent = `Auto-refresh ${autoRefresh ? "enabled" : "disabled"}.`;
      });
    };
  
    selectAllBtn.onclick = () => {
      modItems.forEach(i => selected.add(i.url));
      chrome.storage.local.set({ selected: Array.from(selected) });
      document.querySelectorAll("input[type=checkbox]").forEach(cb => cb.checked = true);
    };
  
    unselectAllBtn.onclick = () => {
      selected.clear();
      chrome.storage.local.set({ selected: [] });
      document.querySelectorAll("input[type=checkbox]").forEach(cb => cb.checked = false);
    };
  
    downloadSelBtn.onclick = () => {
      const toZip = modItems.filter(i => selected.has(i.url));
      if (!toZip.length) {
        progressEl.textContent = "No files selected.";
        return;
      }
      zipAndDownload(toZip);
    };
  
    downloadAllBtn.onclick = () => {
      if (!modItems.length) {
        progressEl.textContent = "No files to download.";
        return;
      }
      zipAndDownload(modItems);
    };
  
    downloadTabsBtn.onclick = async () => {
      progressEl.textContent = "Gathering open LoversLab tabs…";
      const tabs = await chrome.tabs.query({
        url: "https://www.loverslab.com/files/file/*?do=download*"
      });

      if (tabs.length === 0) {
        progressEl.textContent = "No open download tabs found.";
        return;
      }

      let errors = 0;
      let scraped = 0;
      progressEl.textContent = `Scraping ${tabs.length} tab(s)…`;

      const results = await Promise.all(tabs.map(async (tab, idx) => {
        try {
          const res = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
              return Array.from(
                document.querySelectorAll("ul.ipsDataList > li.ipsDataItem")
              ).map(li => {
                const name = li.querySelector("h4 span")?.innerText.trim();
                const url  = li.querySelector("a.ipsButton_primary")?.href;
                return name && url ? { name, url } : null;
              }).filter(Boolean);
            }
          });
          scraped++;
          progressEl.textContent = `Scraped ${scraped}/${tabs.length} tab(s)…`;
          return res;
        } catch (err) {
          errors++;
          progressEl.textContent = `Error scraping tab ${idx + 1}. (${errors} error${errors > 1 ? 's' : ''})`;
          return [{ result: [] }];
        }
      }));

      const allItems = [];
      const seenUrls = new Set();
      results.forEach(r => {
        for (const item of r[0].result) {
          if (!seenUrls.has(item.url)) {
            seenUrls.add(item.url);
            allItems.push(item);
          }
        }
      });

      if (allItems.length === 0) {
        progressEl.textContent = errors
          ? `No files found. (${errors} tab${errors > 1 ? 's' : ''} had errors)`
          : "No files found across tabs.";
        return;
      }

      progressEl.textContent = `Found ${allItems.length} file(s) in ${tabs.length} tab(s). Zipping…`;

      zipAndDownload(allItems);
    };
  });