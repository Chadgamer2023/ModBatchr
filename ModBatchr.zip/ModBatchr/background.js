chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url) {
    const url = new URL(tab.url);
    if (
      url.pathname.startsWith("/files/file/") &&
      !url.searchParams.has("do")
    ) {
      chrome.storage.local.get("autoRefresh", (data) => {
        if (data.autoRefresh) {
          url.searchParams.set("do", "download");
          chrome.tabs.update(tabId, { url: url.toString() });
        }
      });
    }
  }
});
